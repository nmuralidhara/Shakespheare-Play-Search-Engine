import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileReader;
import java.io.FileWriter;
//import javafx.util.Pair; 
public class SceneParser {
//static //	public class Postings{
//		int x;
//		int y;
//		public Postings(int x, int y) {
//			this.x=x;
//			this.y=y;
//		}
//	}
	 public static Map<Long,String>SceneNumtoSceneId;
	 public static Map<String,List<Long>>SceneNumtoPlayId;
	 public static Map<Integer,List<String>>termstoSceneNum;
	 public static Map<String, Map<Integer, List<Integer>>> rawCheck() throws ParseException, FileNotFoundException, IOException{
		 JSONParser parser=new JSONParser();
		 Map<String,  Map<Integer, List<Integer>>>invertedIndex=new HashMap<String,  Map<Integer, List<Integer>>>();
		
//		 Map<Integer,List<String>>termsinDoc=new HashMap<Integer,List<String>>();
		 Map<String,List<String>>termstoPlayId=new HashMap<String,List<String>>();
//		 Map<String,List<String>>termstoSceneId=new HashMap<String,List<String>>();
		 termstoSceneNum=new HashMap<Integer,List<String>>();
		 SceneNumtoSceneId=new HashMap<Long,String>();
		 SceneNumtoPlayId=new HashMap<String,List<Long>>();
		 //		 String s="[0,{\"1\":{\"2\":{\"3\":{\"4\":[5,{\"6\":7}]}}}}]"; 
//		 Object obj=parser.parse(s); JSONArray array=(JSONArray)obj; 
//		 System.out.println("======the 2nd element of array======"); 
//		 System.out.println(array.get(1)); 
//		 System.out.println();
//         JSONObject obj2=(JSONObject)array.get(1); 
//		 System.out.println("======field \"1\"=========="); 
//		 System.out.println(obj2.get("1"));
//         s="{}"; obj=parser.parse(s); System.out.println(obj);
//
//		 s="[5,]"; obj=parser.parse(s); System.out.println(obj);
//
//		 s="[5,,2]"; obj=parser.parse(s); System.out.println(obj);
		 
         
//	        try (FileReader reader = new FileReader("C:\\Users\\V.M.Narpavirajan\\Downloads\\shakespeare-scenes.json\\shakespeare-scenes.json"))
//	        {
//	            //Read JSON file
//	        	JSONParser parser=new JSONParser();
//	            Object obj = parser.parse(reader);
//	            JSONArray employeeList = new JSONArray();
//	            employeeList.add(obj);
//	            System.out.println(employeeList);
//	             
//	            //Iterate over employee array
//	            employeeList.forEach( emp -> parseEmployeeObject( (JSONObject) emp ) );
//	 
//	        } catch (FileNotFoundException e) {
//	            e.printStackTrace();
//	        } catch (IOException e) {
//	            e.printStackTrace();
//	        } catch (ParseException e) {
//	            e.printStackTrace();
//	        }
		 Object obj=parser.parse(new FileReader("C:\\Users\\V.M.Narpavirajan\\Downloads\\shakespeare-scenes.json\\shakespeare-scenes.json"));
		 JSONObject person = (JSONObject) obj;
         
		    

		 JSONArray zoneArray = (JSONArray)person.get("corpus");
		 for(int i=0; i<zoneArray.size(); i++)
	        {
			 List<String> words=new ArrayList<String>();
	          JSONObject miniobj=(JSONObject)zoneArray.get(i);
	          String playId=(String)miniobj.get("playId");
//	          System.out.println(playId);
	          String sceneId=(String)miniobj.get("sceneId");
//	          System.out.println(sceneId);
	          long sceneNum=(long)miniobj.get("sceneNum");
//	          System.out.println(sceneNum);
	          String text=(String)miniobj.get("text");
//	          
	          words.addAll(Arrays.asList(text.split("\\s+")));
//	          termsinDoc.put(i,words);
	          
	          termstoPlayId.put(playId, words);
//	          termstoSceneId.put(sceneId,words);
	          SceneNumtoSceneId.put(sceneNum,sceneId);
	          if(!SceneNumtoPlayId.containsKey(playId)) {
	        	  List<Long>sceneNumToMap=new ArrayList<Long>();
	        	  sceneNumToMap.add(sceneNum);
	        	  SceneNumtoPlayId.put(playId,sceneNumToMap);
	          }
	          else {
	        	  SceneNumtoPlayId.get(playId).add(sceneNum);
	          }
	         
	          termstoSceneNum.put((int)sceneNum,words);
	          int sn=(int)sceneNum;
//	          System.out.println(words[0]);
	 		 for(int j=0;j<words.size();j++) {
//       	  int c=0;
			 System.out.println("hi "+sceneNum);
			
       	  List<Integer>Positions=new ArrayList<Integer>();
       	  for(int k=0;k<words.size();k++) {
       		  if(words.get(j).equals(words.get(k))) {
       			  Positions.add(k);
       		  }
       	  }
       	Map<Integer,List<Integer>>Postings=new HashMap<Integer,List<Integer>>();
       	if(invertedIndex.containsKey(words.get(j))) {
       		if(invertedIndex.get(words.get(j)).containsKey(sn)) {
       			invertedIndex.get(words.get(j)).get(sn).addAll(Positions);
       		}
       		else {
       		invertedIndex.get(words.get(j)).put(sn,Positions);
       		}
       	}
       	else {
       		Postings.put(sn, Positions);
       		invertedIndex.put(words.get(j),Postings);
       	}
//       	 for (Entry<Integer, List<String>> entry : termstoSceneNum.entrySet()) { 
//       		
//             if(entry.getValue().contains(words.get(j))) {
//            	
//            	 for(int k=0;k<entry.getValue().size();k++) {
//            		 
//            		 if(entry.getValue().get(k).equals(words.get(j))) {
//            			 Positions.add(k);
//            		 }
//            	 }
//             }
//             if(!Positions.isEmpty()) {
////            	 int k=entry.getKey();
//            	 Postings.put(entry.getKey(),Positions);
//             }
//             
//             if(invertedIndex.containsKey(words.get(j))) {
//            	 if(invertedIndex.get(words.get(j)).containsKey(entry.getKey())) {
//            		 invertedIndex.get(words.get(j)).get(entry.getKey()).addAll(Positions);
//            	 }
//            	 else {
//            		 invertedIndex.get(words.get(j)).putAll(Postings);
//            	 }
//    			
//    		 }
//             else {
//           	 invertedIndex.put(words.get(j),Postings);
//           }	  
//             }
        }
       	
	          System.out.println(words.size());
	       }  
		

		 
//		    System.out.println(name);

//		    String city = (String) person.get("sceneId");
//		    System.out.println(city);
//
//		    String job = (String) person.get("sceneNum");
//		    System.out.println(job);
//
//		    String text = (String) person.get("text");
//		    System.out.println(text);
//		    JSONArray cars = (JSONArray) person.get("cars");
//
//		    for (Object c : cars)
//		    {
//		      System.out.println(c+"");
//		    }
		return invertedIndex;  
	 }
	 public static boolean IsSceneContainsWord (Map<String,  Map<Integer, List<Integer>>>invertedIndex,int sceneNum,String word) 
	{
		 if(!invertedIndex.containsKey(word)) {
			return false; 
		 }
		 Map<Integer,List<Integer>>hi=invertedIndex.get(word);

		
		 if(hi.containsKey(sceneNum)) {
			return true;
		 }
		 return false;
	   }
	 public static boolean IsSceneContainsWords (Map<String,  Map<Integer, List<Integer>>>invertedIndex,int sceneNum,List<String>words) 
		{
		 int counter=0;
		   for(int i=0;i<words.size();i++) {
			   if(!invertedIndex.containsKey(words.get(i))) {
				   continue;
			   }
			 Map<Integer,List<Integer>>hi=invertedIndex.get(words.get(i));
			 if(hi.containsKey(sceneNum)&&counter==words.size()) {
				return true;
			 }
			 else if(hi.containsKey(sceneNum)) {
				 counter++;
			 }
		   }
			 return false;
		   }
	 public static boolean IsSceneContainsPhrase(Map<String,  Map<Integer, List<Integer>>>invertedIndex,List<String>phrase,long sceneNum) {
              	
			 int counter1=0;
			 int counter2=0;
			 int sn=(int)sceneNum;
			 List<String>value=termstoSceneNum.get(sn);
			if(value.contains(phrase.get(0))) {
				
			    if(WordFrequency(invertedIndex,sn,phrase.get(0))==1) {
			    	for(int k=0;k<phrase.size();k++) {
			    		if(((value.indexOf(phrase.get(0))+k)<value.size())&&(value.get(value.indexOf(phrase.get(0))+k).equals(phrase.get(k)))) {
			    			if(counter1==phrase.size()) {
			    				return true;
			    			}
			    			else {
			    				counter1++;
			    			}
			    		}
			    	}
			    }
			    else if(WordFrequency(invertedIndex,sn,phrase.get(0))>1) {
			    	for(int i=0;i<value.size();i++) {
			    		if(value.get(i).equals(phrase.get(0))) {
			    		for(int k=0;k<phrase.size();k++) {
			    			if(i+k<phrase.size()&&value.get(i+k).equals(phrase.get(k))) {
			    				if(counter2==phrase.size()) {
				    				return true;
				    			}
				    			else {
				    				counter2++;
				    			}
			    			}
			    		}
			    		}
			    	}
			    }
			}
		 
		 return false;
	 }
	 
	 public static int WordFrequency(Map<String,  Map<Integer, List<Integer>>>invertedIndex,int sceneNum,String word) {
		 if(IsSceneContainsWord(invertedIndex,sceneNum,word)) {
			 return invertedIndex.get(word).get(sceneNum).size();
		 }
		 
		 return 0;
	 }
	 public static void FindSceneByWord(Map<String,  Map<Integer, List<Integer>>>invertedIndex,List<String>words,String classifier,String pors,String directory) throws IOException {
		 FileWriter writer=new FileWriter(directory,true);
		 boolean found=false;
		 List<Boolean>marked=new ArrayList<Boolean>();
		 for(int z=0;z<SceneNumtoSceneId.entrySet().size();z++) {
			 marked.add(false);
		 }
		 
		 for(int i=0;i<words.size();i++) {
			 
		 
		 if(classifier.equals("or")) {
			 int j=0;
			 for(Entry<Long,String>entry:SceneNumtoSceneId.entrySet()) {
				 long key=entry.getKey();
				 int keyi=(int)key;

				 if(IsSceneContainsWord(invertedIndex,keyi,words.get(i))){
//					 if(keyi==627) {
//						 System.out.println("hi");
//					 }
					 if(marked.get(j)==false) {
						 marked.remove(j);
						 marked.add(j,true);
					 }
					 else if(marked.get(j)==true) {
						 continue;
					 }
//					 System.out.println((int)key);
					
					 if(pors.equals("s")) {
					 writer.write("SceneNum: "+key+" "+"SceneId:"+" "+entry.getValue());
					 }
					 else if(pors.equals("p")) {
						 List<String>plays=new ArrayList<String>();
						 for(Entry<String,List<Long>>play:SceneNumtoPlayId.entrySet()) {
							 if(play.getValue().contains(key)) {
								 if(!plays.contains(play.getKey().toString())) {
									 
									 plays.add(play.getKey());
									 writer.write("PlayId: "+play.getKey());
								 }
								 
							 }
						 }
					 }
					 
					 
				 }
				 j++;
			 }
		 }
		 else if(classifier.equals("and")) {
			 for(Entry<Long,String>entry:SceneNumtoSceneId.entrySet()) {
				 long key=entry.getKey();
				 if(found||IsSceneContainsWords(invertedIndex,(int)key,words)){
					 System.out.println("SceneNum: "+key+" "+"SceneId:"+" "+entry.getValue());
					 
				}
			
			 }
		 }
		 }
		writer.close(); 
	 }
	 
	 public static void WordFrequencyComparison(Map<String,  Map<Integer, List<Integer>>>invertedIndex,List<String>words,String compWord,String directory) throws IOException {
		 FileWriter writer=new FileWriter(directory,true);
		 List<Boolean>marked=new ArrayList<Boolean>();
		 for(int z=0;z<SceneNumtoSceneId.entrySet().size();z++) {
			 marked.add(false);
		 }
		 
		 for(int i=0;i<words.size();i++) {
			 
		 List<String>pairWords=new ArrayList<String>();
		 pairWords.add(words.get(i));
		 pairWords.add(compWord);
		 int j=0;
		 for(Entry<Long,String>entry:SceneNumtoSceneId.entrySet()) {
			 long key=entry.getKey();
			 if(IsSceneContainsWord(invertedIndex,(int)key,words.get(i))||IsSceneContainsWord(invertedIndex,(int)key,compWord)) {
				 if((WordFrequency(invertedIndex,(int)key,words.get(i))>WordFrequency(invertedIndex,(int)key,compWord))) {
					 if(marked.get(j)==true) {
							continue; 
						 }
					 if(marked.get(j)==false) {
					 marked.remove(j);
					 marked.add(j,true);
				 
				   }
					 writer.write("SceneNum: "+key+" "+"SceneId:"+" "+entry.getValue());
				  

				 }
				 }
		 j++;
		 }
		 writer.close();
		 }
	 }
	 
	 public static void FindSceneByPhrase(Map<String,  Map<Integer, List<Integer>>>invertedIndex,String phrase,String directory) throws IOException {
		 FileWriter writer=new FileWriter(directory,true);
		 List<String>words=Arrays.asList(phrase.split("\\s+"));
		 for(Entry<Long,String>entry:SceneNumtoSceneId.entrySet()) {

			 if(IsSceneContainsPhrase(invertedIndex,words,entry.getKey())) {
				 writer.write("SceneNum: "+entry.getKey()+" "+"SceneId: "+ entry.getValue());
			 }
		 }
		 writer.close();
		 
	 }
//	 public static void main(String[]args) throws IOException, ParseException {
//		 rawCheck();
//	 }
	 public static void main(String[] args) throws IOException, ParseException {
		   Map<String, Map<Integer, List<Integer>>>hey=rawCheck();
		   List<String>terms1=new ArrayList<String>();
		   List<String>terms2=new ArrayList<String>();
		   List<String>terms3=new ArrayList<String>();
		   List<String>terms0=new ArrayList<String>();
		   terms0.add("thee");
		   terms0.add("thou");
		   terms1.add("verona");
		   terms1.add("rome");
		   terms1.add("italy");
		   terms2.add("falstaff");
		   terms3.add("soldier");
		   FindSceneByPhrase(hey,"lady macbeth","C:\\Users\\V.M.Narpavirajan\\Documents\\446\\phrase0.txt");
		   FindSceneByPhrase(hey,"a rose by any other name","C:\\Users\\V.M.Narpavirajan\\Documents\\446\\phrase1.txt");
		   FindSceneByPhrase(hey,"cry havoc","C:\\Users\\V.M.Narpavirajan\\Documents\\446\\phrase2.txt");
		   FindSceneByWord(hey,terms3,"or","p","C:\\Users\\V.M.Narpavirajan\\Documents\\446\\terms3.txt");
		   FindSceneByWord(hey,terms1,"or","s","C:\\Users\\V.M.Narpavirajan\\Documents\\446\\terms1.txt");
		   FindSceneByWord(hey,terms2,"or","s","C:\\Users\\V.M.Narpavirajan\\Documents\\446\\terms2.txt");
		   WordFrequencyComparison(hey,terms0,"you","C:\\Users\\V.M.Narpavirajan\\Documents\\446\\terms0.txt");
//		   PageRank(0.2,0.02,hey);
//		 rawCheck();
	   }
}
